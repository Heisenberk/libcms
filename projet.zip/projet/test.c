#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <cmsint.h>

int main(){
	uint8_t test=2;
	printf_uint8_t_binary(test);
	return 0;
}